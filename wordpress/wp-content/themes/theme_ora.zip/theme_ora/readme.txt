License: GNU GPL, Version 2 (or later)
License URI: http://www.gnu.org/licenses/gpl-2.0.html
By: Xpertosolutions.com
To: Universidad de Otavalo
Date: 2019/05/30
Theme Name: xs_uotavalo
Version: 1.0


INSTALACIÓN

1.	En su panel de administración, vaya a Apariencia -> Temas y haga clic en el botón 'Agregar nuevo'.
2.	Haga click en el Botón 'Subir Tema' y seleccione el archivo del Tema xs_uotavalo.zip.
3.	Haga clic en el botón 'Instalar Ahora' para  instalar el nuevo tema de inmediato.
4.	Haga clic en el botón 'Activar' para usar su nuevo tema instalado.
5.	Navegue a Apariencia> Personalizar en su panel de administración y personalice a gusto.
