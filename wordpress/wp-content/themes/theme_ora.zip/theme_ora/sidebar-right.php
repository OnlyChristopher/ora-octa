<aside class="xs_right_div">
  <?php dynamic_sidebar('xs_right');?>
</aside>
